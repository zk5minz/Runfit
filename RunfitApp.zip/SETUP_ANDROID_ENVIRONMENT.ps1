# RunTracker Android Environment Setup Script
# PowerShell script to set up Android development environment

param(
    [switch]$SkipJava,
    [switch]$SkipAndroid,
    [switch]$Portable
)

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "RunTracker Android 환경 설정 스크립트" -ForegroundColor Cyan  
Write-Host "=====================================" -ForegroundColor Cyan

# Functions
function Write-Success {
    param($Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Error {
    param($Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Info {
    param($Message)
    Write-Host "ℹ️ $Message" -ForegroundColor Blue
}

function Test-AdminRights {
    return ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Download-File {
    param(
        [string]$Url,
        [string]$Output
    )
    try {
        Invoke-WebRequest -Uri $Url -OutFile $Output -UseBasicParsing
        return $true
    }
    catch {
        Write-Error "다운로드 실패: $($_.Exception.Message)"
        return $false
    }
}

# Check admin rights
if (!(Test-AdminRights)) {
    Write-Error "이 스크립트는 관리자 권한이 필요합니다."
    Write-Host "PowerShell을 관리자로 실행한 후 다시 시도하세요." -ForegroundColor Yellow
    
    if (!$Portable) {
        Write-Info "포터블 설치를 원하면 -Portable 매개변수를 사용하세요."
        exit 1
    } else {
        Write-Info "포터블 모드로 계속 진행합니다..."
    }
}

# Set up directories
$BaseDir = if ($Portable) { "C:\temp\RunTracker-Android" } else { "$env:ProgramFiles\RunTracker-Android" }
$JavaDir = "$BaseDir\openjdk"
$AndroidDir = "$BaseDir\android-sdk"

Write-Info "설치 디렉터리: $BaseDir"

if (!(Test-Path $BaseDir)) {
    New-Item -ItemType Directory -Path $BaseDir -Force | Out-Null
    Write-Success "베이스 디렉터리 생성됨: $BaseDir"
}

# Install Java JDK if not skipped
if (!$SkipJava) {
    Write-Info "Java JDK 8 다운로드 및 설치 중..."
    
    $JavaZip = "$BaseDir\openjdk8.zip"
    $JavaUrl = "https://github.com/AdoptOpenJDK/openjdk8-binaries/releases/download/jdk8u292-b10/OpenJDK8U-jdk_x64_windows_hotspot_8u292b10.zip"
    
    if (Download-File -Url $JavaUrl -Output $JavaZip) {
        Write-Info "Java JDK 압축 해제 중..."
        Expand-Archive -Path $JavaZip -DestinationPath $JavaDir -Force
        Remove-Item $JavaZip
        
        # Find extracted JDK directory
        $JdkPath = Get-ChildItem -Path $JavaDir -Directory | Where-Object { $_.Name -like "jdk*" } | Select-Object -First 1
        if ($JdkPath) {
            $global:JAVA_HOME = $JdkPath.FullName
            Write-Success "Java JDK 설치 완료: $global:JAVA_HOME"
        }
    }
}

# Install Android SDK Command Line Tools if not skipped
if (!$SkipAndroid) {
    Write-Info "Android SDK Command Line Tools 다운로드 중..."
    
    $AndroidToolsZip = "$BaseDir\android-tools.zip"
    $AndroidToolsUrl = "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip"
    
    if (Download-File -Url $AndroidToolsUrl -Output $AndroidToolsZip) {
        Write-Info "Android SDK 압축 해제 중..."
        Expand-Archive -Path $AndroidToolsZip -DestinationPath "$AndroidDir\cmdline-tools" -Force
        Remove-Item $AndroidToolsZip
        
        # Rename folder to latest as expected by Android tools
        $ToolsPath = "$AndroidDir\cmdline-tools\cmdline-tools"
        $LatestPath = "$AndroidDir\cmdline-tools\latest"
        if (Test-Path $ToolsPath) {
            Move-Item $ToolsPath $LatestPath
            Write-Success "Android SDK Command Line Tools 설치 완료"
        }
    }
}

# Set up environment variables
Write-Info "환경 변수 설정 중..."

$envVars = @{
    "JAVA_HOME" = $global:JAVA_HOME
    "ANDROID_HOME" = $AndroidDir
    "ANDROID_SDK_ROOT" = $AndroidDir
}

$pathAdditions = @(
    "$global:JAVA_HOME\bin",
    "$AndroidDir\cmdline-tools\latest\bin",
    "$AndroidDir\platform-tools",
    "$AndroidDir\emulator",
    "$AndroidDir\tools",
    "$AndroidDir\tools\bin"
)

if ($Portable) {
    # Create batch file for portable environment
    $BatchContent = "@echo off`n"
    foreach ($var in $envVars.GetEnumerator()) {
        $BatchContent += "set $($var.Key)=$($var.Value)`n"
    }
    $BatchContent += "set PATH=" + ($pathAdditions -join ";") + ";%PATH%`n"
    $BatchContent += "echo Android 개발 환경이 설정되었습니다.`n"
    $BatchContent += "echo JAVA_HOME: %JAVA_HOME%`n"
    $BatchContent += "echo ANDROID_HOME: %ANDROID_HOME%`n"
    $BatchContent += "cd /d %~dp0`n"
    $BatchContent += "cmd /k"
    
    $BatchFile = "$BaseDir\setup-env.bat"
    $BatchContent | Out-File -FilePath $BatchFile -Encoding ASCII
    
    Write-Success "포터블 환경 설정 파일 생성됨: $BatchFile"
    Write-Info "이 파일을 실행하여 Android 개발 환경을 활성화하세요."
} else {
    # Set system environment variables (requires admin)
    foreach ($var in $envVars.GetEnumerator()) {
        [Environment]::SetEnvironmentVariable($var.Key, $var.Value, "Machine")
    }
    
    # Add to PATH
    $currentPath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $newPathItems = $pathAdditions | Where-Object { $currentPath -notlike "*$_*" }
    if ($newPathItems) {
        $newPath = $currentPath + ";" + ($newPathItems -join ";")
        [Environment]::SetEnvironmentVariable("Path", $newPath, "Machine")
    }
    
    Write-Success "시스템 환경 변수 설정 완료"
}

# Install Android SDK packages
if (!$SkipAndroid -and $global:JAVA_HOME) {
    Write-Info "필수 Android SDK 패키지 설치 중..."
    
    $sdkManagerPath = "$AndroidDir\cmdline-tools\latest\bin\sdkmanager.bat"
    
    if (Test-Path $sdkManagerPath) {
        # Set temporary environment for this session
        $env:JAVA_HOME = $global:JAVA_HOME
        $env:ANDROID_HOME = $AndroidDir
        $env:PATH = "$global:JAVA_HOME\bin;$AndroidDir\cmdline-tools\latest\bin;" + $env:PATH
        
        $packages = @(
            "platforms;android-34",
            "build-tools;34.0.0", 
            "platform-tools",
            "tools"
        )
        
        foreach ($package in $packages) {
            Write-Info "설치 중: $package"
            & $sdkManagerPath --sdk_root=$AndroidDir $package
            if ($LASTEXITCODE -eq 0) {
                Write-Success "설치 완료: $package"
            } else {
                Write-Error "설치 실패: $package"
            }
        }
    }
}

# Create verification script
$VerifyScript = @"
@echo off
echo =====================================
echo Android 개발 환경 확인
echo =====================================
echo.

echo JAVA_HOME: %JAVA_HOME%
if exist "%JAVA_HOME%\bin\java.exe" (
    echo ✅ Java 설치됨
    "%JAVA_HOME%\bin\java.exe" -version
) else (
    echo ❌ Java가 설치되지 않았습니다
)

echo.
echo ANDROID_HOME: %ANDROID_HOME%
if exist "%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager.bat" (
    echo ✅ Android SDK 설치됨
) else (
    echo ❌ Android SDK가 설치되지 않았습니다
)

echo.
echo Cordova 요구사항 확인:
cordova requirements

pause
"@

$VerifyScript | Out-File -FilePath "$BaseDir\verify-environment.bat" -Encoding ASCII

Write-Host ""
Write-Success "Android 개발 환경 설정 완료!"
Write-Host ""
Write-Info "다음 단계:"
Write-Host "  1. 환경 설정 확인: $BaseDir\verify-environment.bat" -ForegroundColor Yellow
if ($Portable) {
    Write-Host "  2. 개발 환경 활성화: $BaseDir\setup-env.bat" -ForegroundColor Yellow
}
Write-Host "  3. RunTracker 프로젝트에서 빌드 실행" -ForegroundColor Yellow

Write-Host ""
Write-Info "수동 설치가 필요한 경우:"
Write-Host "  - Android Studio: https://developer.android.com/studio" -ForegroundColor Gray
Write-Host "  - OpenJDK 8: https://adoptopenjdk.net/" -ForegroundColor Gray

# Final verification
Write-Host ""
Write-Info "현재 환경 확인:"
if ($global:JAVA_HOME -and (Test-Path "$global:JAVA_HOME\bin\java.exe")) {
    Write-Success "Java: 설치됨 ($global:JAVA_HOME)"
} else {
    Write-Error "Java: 설치되지 않음"
}

if (Test-Path "$AndroidDir\cmdline-tools\latest\bin\sdkmanager.bat") {
    Write-Success "Android SDK: 설치됨 ($AndroidDir)"
} else {
    Write-Error "Android SDK: 설치되지 않음"
}