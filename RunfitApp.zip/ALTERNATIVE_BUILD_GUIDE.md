# 🚀 RunTracker APK/AAB 대안 빌드 가이드

## 📋 개요

로컬 환경에서 Android SDK 설치가 어려운 경우를 위한 대안적 빌드 방법들을 제공합니다.

## 🛠️ 방법 1: 온라인 빌드 서비스 (권장)

### PhoneGap Build 또는 Cordova Build Services
```bash
# 프로젝트를 ZIP으로 압축
zip -r runtracker-project.zip RunfitApp/

# 온라인 빌드 서비스에 업로드
# - Adobe PhoneGap Build (서비스 종료됨)
# - Cordova CLI + GitHub Actions
# - Firebase App Distribution
# - GitHub Packages
```

### GitHub Actions를 통한 자동 빌드
프로젝트를 GitHub에 업로드 후 다음 워크플로우 사용:

```yaml
# .github/workflows/android-build.yml
name: Android Build
on: [push, pull_request]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
        
    - name: Setup Java JDK
      uses: actions/setup-java@v2
      with:
        java-version: '8'
        distribution: 'adopt'
        
    - name: Setup Android SDK
      uses: android-actions/setup-android@v2
      
    - name: Install Cordova
      run: npm install -g cordova
      
    - name: Install dependencies
      run: cd RunfitApp && cordova prepare
      
    - name: Build APK
      run: cd RunfitApp && cordova build android --debug
      
    - name: Upload APK
      uses: actions/upload-artifact@v2
      with:
        name: app-debug
        path: RunfitApp/platforms/android/app/build/outputs/apk/debug/
```

## 🛠️ 방법 2: Docker 기반 빌드

### Docker 컨테이너에서 빌드
```dockerfile
# Dockerfile
FROM node:18

# Install Java 8
RUN apt-get update && \
    apt-get install -y openjdk-8-jdk && \
    apt-get clean

# Install Android SDK
ENV ANDROID_HOME="/opt/android-sdk"
ENV PATH="${PATH}:${ANDROID_HOME}/cmdline-tools/latest/bin:${ANDROID_HOME}/platform-tools"

RUN mkdir -p ${ANDROID_HOME}/cmdline-tools && \
    cd ${ANDROID_HOME}/cmdline-tools && \
    wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip && \
    unzip commandlinetools-linux-*_latest.zip && \
    mv cmdline-tools latest && \
    rm commandlinetools-linux-*_latest.zip

# Install Cordova
RUN npm install -g cordova

# Accept Android licenses
RUN yes | sdkmanager --licenses

# Install Android SDK packages
RUN sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"

WORKDIR /app
COPY . .

# Build commands
RUN cordova build android --debug
```

### Docker 빌드 실행
```bash
# Docker 이미지 빌드
docker build -t runtracker-builder .

# 컨테이너에서 APK 추출
docker run --rm -v $(pwd)/output:/output runtracker-builder \
  cp platforms/android/app/build/outputs/apk/debug/app-debug.apk /output/
```

## 🛠️ 방법 3: 클라우드 빌드 서비스

### 1. Buildozer (Kivy/Python 기반)
```bash
# buildozer.spec 생성 후
buildozer android debug
```

### 2. Expo (React Native 기반으로 변환 필요)
```bash
expo build:android
```

### 3. CodeMagic (Flutter/Cordova 지원)
- https://codemagic.io/
- GitHub 연동하여 자동 빌드

### 4. Bitrise (모바일 CI/CD)
- https://www.bitrise.io/
- Cordova 워크플로우 지원

## 🛠️ 방법 4: 웹 기반 APK 생성 도구

### APK Builder Online
```javascript
// manifest.json을 Android manifest로 변환
{
  "name": "RunTracker",
  "short_name": "RunTracker", 
  "start_url": "index.html",
  "display": "standalone",
  "orientation": "portrait",
  "theme_color": "#4F46E5",
  "background_color": "#667eea",
  "icons": [
    {
      "src": "icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    }
  ]
}
```

### PWA to APK 변환기
- PWABuilder (Microsoft)
- Trusted Web Activity 기반 APK 생성

## 🛠️ 방법 5: 로컬 환경 간소화 설정

### 최소 요구사항만 설치
```bash
# Android SDK Platform Tools만 설치
# https://developer.android.com/studio/releases/platform-tools

# 환경변수 설정
export ANDROID_HOME="C:\platform-tools"
export PATH="$PATH:$ANDROID_HOME"

# Gradle Wrapper 사용
cd RunfitApp/platforms/android
.\gradlew assembleDebug
```

### Cordova Browser 플랫폼으로 테스트
```bash
cd RunfitApp
cordova platform add browser
cordova build browser
cordova serve browser
```

## 📱 생성 가능한 파일 유형

### 1. 디버그 APK
- **용도**: 개발 및 테스트
- **서명**: 디버그 서명 (자동)
- **배포**: 직접 설치만 가능

### 2. 릴리즈 APK
- **용도**: 프로덕션 배포
- **서명**: 커스텀 키스토어 필요
- **배포**: Google Play Store 또는 직접 배포

### 3. AAB (Android App Bundle)
- **용도**: Google Play Store 최적화
- **장점**: 동적 배포, 작은 다운로드 크기
- **단점**: Google Play Store에서만 사용 가능

## 🔐 키스토어 생성 (릴리즈 빌드용)

### 로컬에서 키스토어 생성
```bash
# keytool 사용 (Java 필요)
keytool -genkey -v -keystore runtracker-release.keystore \
  -alias runtracker -keyalg RSA -keysize 2048 -validity 10000

# build.json 설정
{
  "android": {
    "release": {
      "keystore": "runtracker-release.keystore",
      "storePassword": "YOUR_PASSWORD",
      "alias": "runtracker", 
      "password": "YOUR_PASSWORD"
    }
  }
}
```

### 온라인 키스토어 생성기 사용
- Android Asset Studio
- 온라인 Keystore Generator 도구들

## 📊 각 방법의 장단점 비교

| 방법 | 난이도 | 시간 | 커스터마이징 | 비용 |
|------|--------|------|--------------|------|
| GitHub Actions | 중간 | 10-20분 | 높음 | 무료 |
| Docker | 높음 | 30-60분 | 매우 높음 | 무료 |
| 클라우드 서비스 | 낮음 | 5-15분 | 중간 | 유료/무료 |
| PWA 변환기 | 매우 낮음 | 2-5분 | 낮음 | 무료 |
| 로컬 최소 설정 | 중간 | 20-40분 | 높음 | 무료 |

## 🚀 추천 워크플로우

### 단계별 추천 순서:

1. **PWA 변환기로 빠른 프로토타입** (즉시)
2. **GitHub Actions로 정식 빌드** (1시간 설정)
3. **로컬 환경 구축** (필요시)

### 현재 상황에 맞는 추천:
```bash
# 1. 즉시 테스트용 APK가 필요한 경우
→ PWA Builder 또는 온라인 변환기 사용

# 2. 정식 배포용 APK/AAB가 필요한 경우  
→ GitHub Actions 워크플로우 설정

# 3. 지속적인 개발이 필요한 경우
→ 로컬 Android SDK 환경 구축
```

## 📞 지원 리소스

### 온라인 도구들
- **PWA Builder**: https://www.pwabuilder.com/
- **Cordova 온라인 빌드**: https://build.apache.org/
- **Android Asset Studio**: https://romannurik.github.io/AndroidAssetStudio/

### 클라우드 CI/CD
- **GitHub Actions**: https://github.com/features/actions
- **CodeMagic**: https://codemagic.io/
- **Bitrise**: https://www.bitrise.io/

### 문서 및 가이드
- **Cordova CLI 가이드**: https://cordova.apache.org/docs/en/latest/guide/cli/
- **Android 빌드 가이드**: https://cordova.apache.org/docs/en/latest/guide/platforms/android/

---

이 가이드를 따라 로컬 환경 설정 없이도 RunTracker Android 앱을 빌드할 수 있습니다! 🎉