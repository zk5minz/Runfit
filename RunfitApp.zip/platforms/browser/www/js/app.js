class RunTracker {
    constructor() {
        this.currentScreen = 'ready';
        this.isRunning = false;
        this.isPaused = false;
        this.startTime = null;
        this.pausedTime = 0;
        this.runTimer = null;
        
        // Initialize components
        this.gpsTracker = new GPSTracker();
        this.bluetoothConnector = new BluetoothConnector();
        this.dataManager = new DataManager();
        
        // Maps
        this.readyMap = null;
        this.routeMap = null;
        
        // Running data
        this.currentRunData = {
            distance: 0,
            duration: 0,
            pace: 0,
            averagePace: 0,
            calories: 0,
            heartRate: 0,
            route: []
        };
        
        // Initialize app
        this.init();
    }

    async init() {
        console.log('Initializing RunTracker app...');
        
        // Wait for Cordova device ready event
        document.addEventListener('deviceready', () => {
            console.log('Cordova device ready');
            this.onDeviceReady();
        }, false);
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Initialize GPS callbacks
        this.setupGPSCallbacks();
        
        // Initialize Bluetooth callbacks
        this.setupBluetoothCallbacks();
        
        // Load initial data
        this.loadTotalStats();
        
        // Initialize ready screen
        await this.initializeReadyScreen();
        
        console.log('RunTracker app initialized');
    }

    onDeviceReady() {
        console.log('Device is ready');
        
        // Configure status bar
        if (window.StatusBar) {
            StatusBar.styleLightContent();
            StatusBar.backgroundColorByHexString('#4F46E5');
        }
        
        // Keep screen awake during running
        if (window.plugins && window.plugins.insomnia) {
            // Will be activated when running starts
        }
        
        // Enable background mode
        if (window.cordova && window.cordova.plugins.backgroundMode) {
            cordova.plugins.backgroundMode.setDefaults({
                title: 'RunTracker',
                text: '런닝 추적 중...',
                icon: 'icon',
                color: '4F46E5',
                resume: true,
                hidden: false,
                bigText: false,
                silent: false
            });
        }
    }

    setupEventListeners() {
        // Ready screen
        document.getElementById('start-running-btn').addEventListener('click', () => this.startRunning());
        document.getElementById('view-records-btn').addEventListener('click', () => this.showRecordScreen());
        
        // Running screen
        document.getElementById('back-to-ready').addEventListener('click', () => this.showReadyScreen());
        document.getElementById('pause-resume-btn').addEventListener('click', () => this.togglePauseResume());
        document.getElementById('finish-btn').addEventListener('click', () => this.finishRunning());
        
        // Record screen
        document.getElementById('back-to-ready-from-record').addEventListener('click', () => this.showReadyScreen());
        document.getElementById('exit-app').addEventListener('click', () => this.exitApp());
        document.getElementById('year-selector').addEventListener('change', () => this.updateCalendar());
        document.getElementById('month-selector').addEventListener('change', () => this.updateCalendar());
        
        // Modal
        document.getElementById('close-modal').addEventListener('click', () => this.closeModal());
        document.getElementById('run-detail-modal').addEventListener('click', (e) => {
            if (e.target.id === 'run-detail-modal') this.closeModal();
        });
    }

    setupGPSCallbacks() {
        this.gpsTracker.setCallbacks({
            onLocationUpdate: (position) => {
                this.updateReadyMapLocation(position);
            },
            onDistanceUpdate: (distance) => {
                this.currentRunData.distance = distance;
                this.updateRunningDisplay();
            },
            onError: (error) => {
                this.showLocationStatus(error, 'error');
            }
        });
    }

    setupBluetoothCallbacks() {
        this.bluetoothConnector.setCallbacks({
            onHeartRateUpdate: (heartRate) => {
                this.currentRunData.heartRate = heartRate;
                this.updateHeartRateDisplay(heartRate);
            },
            onConnectionUpdate: (connected, deviceName) => {
                this.updateBluetoothStatus(connected, deviceName);
            },
            onError: (error) => {
                console.error('Bluetooth error:', error);
            }
        });
    }

    async initializeReadyScreen() {
        try {
            this.showLocationStatus('위치 정보를 가져오는 중...', 'loading');
            
            // Initialize map
            this.readyMap = L.map('ready-map').setView([37.5665, 126.9780], 15);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(this.readyMap);

            // Request GPS permission
            const position = await this.gpsTracker.requestPermission();
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            
            // Update map with user location
            this.readyMap.setView([lat, lon], 16);
            this.addUserLocationMarker(lat, lon);
            
            this.showLocationStatus('위치 확인 완료', 'success');
            
            // Hide status after 2 seconds
            setTimeout(() => {
                const status = document.getElementById('location-status');
                if (status) status.style.display = 'none';
            }, 2000);
            
        } catch (error) {
            this.showLocationStatus(error.message, 'error');
            // Still show map with default location
            if (!this.readyMap) {
                this.readyMap = L.map('ready-map').setView([37.5665, 126.9780], 15);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(this.readyMap);
            }
        }
    }

    addUserLocationMarker(lat, lon) {
        // Remove existing marker
        if (this.userMarker) {
            this.readyMap.removeLayer(this.userMarker);
        }

        // Create pulsing red marker
        const markerIcon = L.divIcon({
            className: 'user-location-marker',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        this.userMarker = L.marker([lat, lon], { icon: markerIcon }).addTo(this.readyMap);
    }

    updateReadyMapLocation(position) {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        
        if (this.readyMap && this.currentScreen === 'ready') {
            this.addUserLocationMarker(lat, lon);
        }
    }

    showLocationStatus(message, type) {
        const status = document.getElementById('location-status');
        if (status) {
            status.textContent = message;
            status.className = `location-status ${type}`;
            status.style.display = 'block';
        }
    }

    loadTotalStats() {
        const stats = this.dataManager.getTotalStats();
        
        document.getElementById('total-distance').textContent = `${stats.totalDistance.toFixed(2)} km`;
        document.getElementById('total-time').textContent = this.dataManager.formatTime(stats.totalTime);
        
        // Update record screen totals too
        document.getElementById('record-total-distance').textContent = `${stats.totalDistance.toFixed(2)} km`;
        document.getElementById('record-total-time').textContent = this.dataManager.formatTime(stats.totalTime);
    }

    async startRunning() {
        try {
            // Start GPS tracking
            if (!this.gpsTracker.startTracking()) {
                throw new Error('GPS 추적을 시작할 수 없습니다');
            }

            // Reset running data
            this.currentRunData = {
                distance: 0,
                duration: 0,
                pace: 0,
                averagePace: 0,
                calories: 0,
                heartRate: 0,
                route: []
            };

            this.isRunning = true;
            this.isPaused = false;
            this.startTime = Date.now();
            this.pausedTime = 0;

            // Start timer
            this.runTimer = setInterval(() => {
                if (!this.isPaused) {
                    this.updateRunningTimer();
                }
            }, 1000);

            // Try to connect heart rate monitor (optional)
            if (this.bluetoothConnector.isBluetoothSupported()) {
                // Start simulation for demo (remove in production)
                this.bluetoothConnector.startSimulation();
            }

            this.showRunningScreen();

        } catch (error) {
            alert(error.message);
        }
    }

    togglePauseResume() {
        const btn = document.getElementById('pause-resume-btn');
        const icon = btn.querySelector('i');
        
        if (this.isPaused) {
            // Resume
            this.isPaused = false;
            this.startTime = Date.now() - this.currentRunData.duration;
            btn.innerHTML = '<i class="fas fa-pause"></i> 일시정지';
            btn.className = 'control-btn pause-btn';
        } else {
            // Pause
            this.isPaused = true;
            this.pausedTime += Date.now() - this.startTime;
            btn.innerHTML = '<i class="fas fa-play"></i> 재시작';
            btn.className = 'control-btn pause-btn resume';
        }
    }

    async finishRunning() {
        if (!confirm('런닝을 종료하시겠습니까?')) {
            return;
        }

        // Stop tracking
        this.gpsTracker.stopTracking();
        this.bluetoothConnector.stopSimulation(); // Remove in production
        
        if (this.runTimer) {
            clearInterval(this.runTimer);
            this.runTimer = null;
        }

        // Calculate final metrics
        const finalDistance = this.gpsTracker.getTotalDistance();
        const finalDuration = this.isPaused ? this.pausedTime : Date.now() - this.startTime;
        const route = this.gpsTracker.getRoute();

        // Save run data
        const runData = {
            distance: finalDistance,
            duration: finalDuration,
            averagePace: finalDistance > 0 ? (finalDuration / 60000) / finalDistance : 0,
            calories: this.dataManager.calculateCalories(finalDistance, this.dataManager.getSettings().weight, finalDuration),
            heartRate: this.currentRunData.heartRate,
            route: route
        };

        this.dataManager.addRun(runData);
        this.loadTotalStats();

        // Reset state
        this.isRunning = false;
        this.isPaused = false;
        this.currentRunData = { distance: 0, duration: 0, pace: 0, averagePace: 0, calories: 0, heartRate: 0, route: [] };

        // Show completion message
        alert(`런닝 완료!\n거리: ${finalDistance.toFixed(2)} km\n시간: ${this.dataManager.formatTime(finalDuration)}\n평균 페이스: ${this.dataManager.formatPace(runData.averagePace)}`);

        this.showReadyScreen();
    }

    updateRunningTimer() {
        if (this.isPaused) return;
        
        this.currentRunData.duration = Date.now() - this.startTime;
        this.updateRunningDisplay();
    }

    updateRunningDisplay() {
        // Update distance
        document.getElementById('current-distance').textContent = this.currentRunData.distance.toFixed(2);
        
        // Update time
        document.getElementById('current-time').textContent = this.dataManager.formatTime(this.currentRunData.duration);
        
        // Update paces
        if (this.currentRunData.distance > 0) {
            const averagePace = (this.currentRunData.duration / 60000) / this.currentRunData.distance;
            document.getElementById('average-pace').textContent = this.dataManager.formatPace(averagePace);
            
            // Calculate current pace (last 1km or available distance)
            const currentPace = this.gpsTracker.calculateCurrentPace(this.currentRunData.duration);
            document.getElementById('current-pace').textContent = this.dataManager.formatPace(currentPace);
        }
        
        // Update calories
        const calories = this.dataManager.calculateCalories(
            this.currentRunData.distance, 
            this.dataManager.getSettings().weight, 
            this.currentRunData.duration
        );
        document.getElementById('calories').textContent = calories;
    }

    updateHeartRateDisplay(heartRate) {
        document.getElementById('heart-rate').textContent = `${heartRate} BPM`;
    }

    updateBluetoothStatus(connected, deviceName) {
        const heartRateElement = document.getElementById('heart-rate');
        if (connected && deviceName) {
            heartRateElement.textContent = '연결됨';
        } else {
            heartRateElement.textContent = '연결되지 않음';
        }
    }

    showReadyScreen() {
        this.switchScreen('ready');
        
        // Reinitialize map if needed
        setTimeout(() => {
            if (this.readyMap) {
                this.readyMap.invalidateSize();
            }
        }, 300);
    }

    showRunningScreen() {
        this.switchScreen('running');
    }

    showRecordScreen() {
        this.switchScreen('record');
        this.initializeRecordScreen();
    }

    switchScreen(screenName) {
        const screens = document.querySelectorAll('.screen');
        screens.forEach(screen => screen.classList.remove('active'));
        
        document.getElementById(`${screenName}-screen`).classList.add('active');
        this.currentScreen = screenName;
    }

    initializeRecordScreen() {
        this.loadTotalStats();
        this.setupDateSelectors();
        this.updateCalendar();
    }

    setupDateSelectors() {
        const yearSelect = document.getElementById('year-selector');
        const currentYear = new Date().getFullYear();
        
        // Clear existing options
        yearSelect.innerHTML = '';
        
        // Add years (current year and 2 years back)
        for (let year = currentYear; year >= currentYear - 2; year--) {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year + '년';
            if (year === currentYear) option.selected = true;
            yearSelect.appendChild(option);
        }
        
        // Set current month
        document.getElementById('month-selector').value = new Date().getMonth();
    }

    updateCalendar() {
        const year = parseInt(document.getElementById('year-selector').value);
        const month = parseInt(document.getElementById('month-selector').value);
        
        this.generateCalendar(year, month);
        this.updateMonthlySummary(year, month);
    }

    generateCalendar(year, month) {
        const calendar = document.getElementById('calendar');
        calendar.innerHTML = '';
        
        // Add day headers
        const dayHeaders = ['일', '월', '화', '수', '목', '금', '토'];
        dayHeaders.forEach(day => {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day header';
            dayElement.textContent = day;
            calendar.appendChild(dayElement);
        });
        
        // Get first day of month and number of days
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        // Add empty cells for days before month starts
        for (let i = 0; i < firstDay; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day other-month';
            calendar.appendChild(emptyDay);
        }
        
        // Add days of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            dayElement.textContent = day;
            
            const currentDate = new Date(year, month, day);
            const runs = this.dataManager.getRunsByDate(currentDate);
            
            if (runs.length > 0) {
                dayElement.classList.add('has-run');
                dayElement.addEventListener('click', () => {
                    this.showRunDetails(currentDate, runs);
                });
            }
            
            // Mark today
            const today = new Date();
            if (currentDate.toDateString() === today.toDateString()) {
                dayElement.classList.add('today');
            }
            
            calendar.appendChild(dayElement);
        }
    }

    updateMonthlySummary(year, month) {
        const stats = this.dataManager.getMonthlyStats(year, month);
        
        document.getElementById('monthly-distance').textContent = `${stats.totalDistance.toFixed(2)} km`;
        document.getElementById('monthly-time').textContent = this.dataManager.formatTime(stats.totalTime);
        document.getElementById('monthly-pace').textContent = `${this.dataManager.formatPace(stats.averagePace)} /km`;
    }

    showRunDetails(date, runs) {
        const modal = document.getElementById('run-detail-modal');
        const modalDate = document.getElementById('modal-date');
        const runDetails = document.getElementById('run-details');
        
        modalDate.textContent = date.toLocaleDateString('ko-KR', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        
        runDetails.innerHTML = '';
        
        runs.forEach((run, index) => {
            const runElement = document.createElement('div');
            runElement.className = 'run-item';
            
            runElement.innerHTML = `
                <h4>런닝 ${index + 1}</h4>
                <div class="run-metrics">
                    <div class="run-metric">
                        <span class="label">거리:</span>
                        <span class="value">${run.distance.toFixed(2)} km</span>
                    </div>
                    <div class="run-metric">
                        <span class="label">시간:</span>
                        <span class="value">${this.dataManager.formatTime(run.duration)}</span>
                    </div>
                    <div class="run-metric">
                        <span class="label">평균 페이스:</span>
                        <span class="value">${this.dataManager.formatPace(run.averagePace)} /km</span>
                    </div>
                    <div class="run-metric">
                        <span class="label">칼로리:</span>
                        <span class="value">${run.calories || 0} cal</span>
                    </div>
                </div>
            `;
            
            runDetails.appendChild(runElement);
        });
        
        // Show route map for the first run with route data
        const runWithRoute = runs.find(run => run.route && run.route.length > 0);
        if (runWithRoute) {
            this.showRouteMap(runWithRoute.route);
        }
        
        modal.classList.add('active');
    }

    showRouteMap(route) {
        setTimeout(() => {
            const mapElement = document.getElementById('route-map');
            
            if (this.routeMap) {
                this.routeMap.remove();
            }
            
            this.routeMap = L.map(mapElement).setView([route[0].latitude, route[0].longitude], 15);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(this.routeMap);
            
            // Draw route
            const routeCoords = route.map(point => [point.latitude, point.longitude]);
            const routeLine = L.polyline(routeCoords, { color: '#10B981', weight: 4 }).addTo(this.routeMap);
            
            // Add start/finish markers
            L.marker([route[0].latitude, route[0].longitude])
                .bindPopup('시작점')
                .addTo(this.routeMap);
            
            L.marker([route[route.length - 1].latitude, route[route.length - 1].longitude])
                .bindPopup('종료점')
                .addTo(this.routeMap);
            
            // Fit map to route
            this.routeMap.fitBounds(routeLine.getBounds(), { padding: [10, 10] });
            
        }, 100);
    }

    closeModal() {
        const modal = document.getElementById('run-detail-modal');
        modal.classList.remove('active');
        
        if (this.routeMap) {
            this.routeMap.remove();
            this.routeMap = null;
        }
    }

    exitApp() {
        if (confirm('앱을 종료하시겠습니까?')) {
            window.close();
        }
    }
}

// Service Worker registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.runTracker = new RunTracker();
});