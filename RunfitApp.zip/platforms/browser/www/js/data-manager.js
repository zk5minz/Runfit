class DataManager {
    constructor() {
        this.storageKey = 'runtracker-data';
        this.data = this.loadData();
    }

    // Load data from localStorage
    loadData() {
        try {
            const stored = localStorage.getItem(this.storageKey);
            if (stored) {
                return JSON.parse(stored);
            }
        } catch (error) {
            console.error('Error loading data:', error);
        }

        // Return default data structure
        return {
            runs: [],
            totalDistance: 0,
            totalTime: 0,
            settings: {
                units: 'km',
                targetPace: 6, // minutes per km
                weight: 70, // kg for calorie calculation
                age: 30
            },
            achievements: [],
            version: '1.0'
        };
    }

    // Save data to localStorage
    saveData() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.data));
            return true;
        } catch (error) {
            console.error('Error saving data:', error);
            return false;
        }
    }

    // Add a new run
    addRun(runData) {
        const run = {
            id: Date.now().toString(),
            date: new Date().toISOString(),
            distance: runData.distance || 0,
            duration: runData.duration || 0,
            pace: runData.pace || 0,
            averagePace: runData.averagePace || 0,
            calories: runData.calories || 0,
            heartRate: runData.heartRate || null,
            route: runData.route || [],
            weather: runData.weather || null,
            notes: runData.notes || '',
            createdAt: Date.now()
        };

        this.data.runs.push(run);
        this.updateTotals();
        this.saveData();
        
        return run.id;
    }

    // Get all runs
    getAllRuns() {
        return this.data.runs.sort((a, b) => new Date(b.date) - new Date(a.date));
    }

    // Get runs by date range
    getRunsByDateRange(startDate, endDate) {
        return this.data.runs.filter(run => {
            const runDate = new Date(run.date);
            return runDate >= startDate && runDate <= endDate;
        });
    }

    // Get runs for a specific month
    getRunsByMonth(year, month) {
        return this.data.runs.filter(run => {
            const runDate = new Date(run.date);
            return runDate.getFullYear() === year && runDate.getMonth() === month;
        });
    }

    // Get runs for a specific date
    getRunsByDate(date) {
        const targetDate = new Date(date);
        return this.data.runs.filter(run => {
            const runDate = new Date(run.date);
            return runDate.toDateString() === targetDate.toDateString();
        });
    }

    // Get run by ID
    getRunById(id) {
        return this.data.runs.find(run => run.id === id);
    }

    // Update run
    updateRun(id, updates) {
        const runIndex = this.data.runs.findIndex(run => run.id === id);
        if (runIndex !== -1) {
            this.data.runs[runIndex] = { ...this.data.runs[runIndex], ...updates };
            this.updateTotals();
            this.saveData();
            return true;
        }
        return false;
    }

    // Delete run
    deleteRun(id) {
        const runIndex = this.data.runs.findIndex(run => run.id === id);
        if (runIndex !== -1) {
            this.data.runs.splice(runIndex, 1);
            this.updateTotals();
            this.saveData();
            return true;
        }
        return false;
    }

    // Update totals (distance and time)
    updateTotals() {
        this.data.totalDistance = this.data.runs.reduce((total, run) => total + (run.distance || 0), 0);
        this.data.totalTime = this.data.runs.reduce((total, run) => total + (run.duration || 0), 0);
    }

    // Get total statistics
    getTotalStats() {
        return {
            totalDistance: this.data.totalDistance,
            totalTime: this.data.totalTime,
            totalRuns: this.data.runs.length,
            averagePace: this.calculateAveragePace(),
            totalCalories: this.data.runs.reduce((total, run) => total + (run.calories || 0), 0)
        };
    }

    // Get monthly statistics
    getMonthlyStats(year, month) {
        const monthlyRuns = this.getRunsByMonth(year, month);
        const totalDistance = monthlyRuns.reduce((total, run) => total + (run.distance || 0), 0);
        const totalTime = monthlyRuns.reduce((total, run) => total + (run.duration || 0), 0);
        const totalCalories = monthlyRuns.reduce((total, run) => total + (run.calories || 0), 0);

        return {
            totalDistance,
            totalTime,
            totalRuns: monthlyRuns.length,
            averagePace: totalDistance > 0 ? totalTime / 60000 / totalDistance : 0,
            totalCalories,
            runs: monthlyRuns
        };
    }

    // Calculate average pace across all runs
    calculateAveragePace() {
        if (this.data.totalDistance === 0) return 0;
        return (this.data.totalTime / 60000) / this.data.totalDistance; // minutes per km
    }

    // Format time (milliseconds to HH:MM:SS)
    formatTime(milliseconds) {
        const hours = Math.floor(milliseconds / 3600000);
        const minutes = Math.floor((milliseconds % 3600000) / 60000);
        const seconds = Math.floor((milliseconds % 60000) / 1000);
        
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    // Format pace (minutes per km to MM:SS)
    formatPace(paceMinutes) {
        if (paceMinutes === 0) return '0:00';
        
        const minutes = Math.floor(paceMinutes);
        const seconds = Math.floor((paceMinutes - minutes) * 60);
        
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    // Format distance
    formatDistance(distance) {
        return distance.toFixed(2);
    }

    // Calculate calories burned (simplified formula)
    calculateCalories(distance, weight = 70, duration = 0) {
        // MET (Metabolic Equivalent) for running varies by pace
        // Approximate: 8 MET for moderate running (6-7 mph)
        const durationHours = duration / 3600000;
        const met = 8; // Can be adjusted based on pace
        return Math.round(met * weight * durationHours);
    }

    // Get settings
    getSettings() {
        return this.data.settings;
    }

    // Update settings
    updateSettings(newSettings) {
        this.data.settings = { ...this.data.settings, ...newSettings };
        this.saveData();
    }

    // Export data as JSON
    exportData() {
        return JSON.stringify(this.data, null, 2);
    }

    // Import data from JSON
    importData(jsonData) {
        try {
            const imported = JSON.parse(jsonData);
            // Validate data structure
            if (imported.runs && Array.isArray(imported.runs)) {
                this.data = imported;
                this.updateTotals();
                this.saveData();
                return true;
            }
        } catch (error) {
            console.error('Error importing data:', error);
        }
        return false;
    }

    // Clear all data
    clearAllData() {
        this.data = {
            runs: [],
            totalDistance: 0,
            totalTime: 0,
            settings: this.data.settings,
            achievements: [],
            version: '1.0'
        };
        this.saveData();
    }

    // Get personal records
    getPersonalRecords() {
        if (this.data.runs.length === 0) {
            return {
                longestRun: null,
                fastestPace: null,
                longestTime: null,
                mostCalories: null
            };
        }

        const longestRun = this.data.runs.reduce((max, run) => 
            run.distance > (max.distance || 0) ? run : max, this.data.runs[0]);

        const fastestPace = this.data.runs.reduce((fastest, run) => 
            (run.averagePace || Infinity) < (fastest.averagePace || Infinity) && run.averagePace > 0 ? run : fastest, this.data.runs[0]);

        const longestTime = this.data.runs.reduce((max, run) => 
            run.duration > (max.duration || 0) ? run : max, this.data.runs[0]);

        const mostCalories = this.data.runs.reduce((max, run) => 
            (run.calories || 0) > (max.calories || 0) ? run : max, this.data.runs[0]);

        return {
            longestRun,
            fastestPace,
            longestTime,
            mostCalories
        };
    }

    // Get running streak (consecutive days)
    getRunningStreak() {
        const sortedRuns = this.data.runs.sort((a, b) => new Date(b.date) - new Date(a.date));
        if (sortedRuns.length === 0) return 0;

        let streak = 0;
        let currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        for (const run of sortedRuns) {
            const runDate = new Date(run.date);
            runDate.setHours(0, 0, 0, 0);
            
            const daysDiff = (currentDate - runDate) / (1000 * 60 * 60 * 24);
            
            if (daysDiff === streak) {
                streak++;
                currentDate.setDate(currentDate.getDate() - 1);
            } else {
                break;
            }
        }

        return streak;
    }

    // Get weekly summary
    getWeeklySummary() {
        const now = new Date();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay()); // Start of week (Sunday)
        weekStart.setHours(0, 0, 0, 0);
        
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);
        weekEnd.setHours(23, 59, 59, 999);

        const weeklyRuns = this.getRunsByDateRange(weekStart, weekEnd);
        const totalDistance = weeklyRuns.reduce((total, run) => total + (run.distance || 0), 0);
        const totalTime = weeklyRuns.reduce((total, run) => total + (run.duration || 0), 0);

        return {
            totalDistance,
            totalTime,
            totalRuns: weeklyRuns.length,
            averagePace: totalDistance > 0 ? totalTime / 60000 / totalDistance : 0,
            runs: weeklyRuns
        };
    }
}

// Export for use in other modules
window.DataManager = DataManager;