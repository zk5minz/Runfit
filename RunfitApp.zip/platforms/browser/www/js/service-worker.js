const CACHE_NAME = 'runtracker-v1.0';
const urlsToCache = [
    '/',
    '/index.html',
    '/styles.css',
    '/app.js',
    '/gps-tracker.js',
    '/bluetooth-connector.js',
    '/data-manager.js',
    '/manifest.json',
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'
];

// Install event - cache resources
self.addEventListener('install', event => {
    console.log('Service Worker installing...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Opened cache');
                return cache.addAll(urlsToCache);
            })
            .catch(error => {
                console.error('Failed to cache resources:', error);
            })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
    console.log('Service Worker activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', event => {
    // Skip non-GET requests
    if (event.request.method !== 'GET') {
        return;
    }

    // Skip chrome-extension requests
    if (event.request.url.startsWith('chrome-extension://')) {
        return;
    }

    // Skip requests for tiles (they're too many and dynamic)
    if (event.request.url.includes('tile.openstreetmap.org')) {
        return;
    }

    event.respondWith(
        caches.match(event.request)
            .then(response => {
                // Return cached version or fetch from network
                if (response) {
                    console.log('Serving from cache:', event.request.url);
                    return response;
                }
                
                console.log('Fetching from network:', event.request.url);
                return fetch(event.request)
                    .then(response => {
                        // Don't cache non-successful responses
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }

                        // Clone the response
                        const responseToCache = response.clone();

                        caches.open(CACHE_NAME)
                            .then(cache => {
                                cache.put(event.request, responseToCache);
                            });

                        return response;
                    })
                    .catch(error => {
                        console.error('Fetch failed:', error);
                        
                        // Return a custom offline page for HTML requests
                        if (event.request.destination === 'document') {
                            return caches.match('/index.html');
                        }
                        
                        throw error;
                    });
            })
    );
});

// Background sync for saving run data when online
self.addEventListener('sync', event => {
    if (event.tag === 'background-sync-runs') {
        console.log('Background sync triggered for runs');
        event.waitUntil(syncRuns());
    }
});

// Push notifications for running reminders
self.addEventListener('push', event => {
    console.log('Push notification received');
    
    const options = {
        body: event.data ? event.data.text() : 'RunTracker에서 알림이 왔습니다',
        icon: '/icons/icon-192x192.png',
        badge: '/icons/badge-72x72.png',
        vibrate: [200, 100, 200],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        },
        actions: [
            {
                action: 'start-run',
                title: '런닝 시작',
                icon: '/icons/play-icon.png'
            },
            {
                action: 'dismiss',
                title: '닫기',
                icon: '/icons/close-icon.png'
            }
        ]
    };

    event.waitUntil(
        self.registration.showNotification('RunTracker', options)
    );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
    console.log('Notification clicked:', event.action);
    
    event.notification.close();

    if (event.action === 'start-run') {
        // Open app and navigate to ready screen
        event.waitUntil(
            clients.openWindow('/')
        );
    } else if (event.action === 'dismiss') {
        // Just close the notification
        return;
    } else {
        // Default action - open app
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

// Sync runs data when connection is restored
async function syncRuns() {
    try {
        // This would sync with a server if implemented
        console.log('Syncing runs data...');
        
        // For now, just log that sync would happen
        // In a real app, you'd send stored runs to a server
        const cache = await caches.open(CACHE_NAME);
        const keys = await cache.keys();
        
        console.log('Cached resources:', keys.length);
        
        return Promise.resolve();
    } catch (error) {
        console.error('Sync failed:', error);
        throw error;
    }
}

// Handle app installation prompt
self.addEventListener('beforeinstallprompt', event => {
    console.log('Install prompt triggered');
    // Store the event to trigger it later
    self.deferredPrompt = event;
    event.preventDefault();
});

// Monitor app installation
self.addEventListener('appinstalled', event => {
    console.log('RunTracker app installed successfully');
});

// Handle app visibility changes
self.addEventListener('visibilitychange', event => {
    if (document.hidden) {
        console.log('App went to background');
        // Could pause non-essential operations
    } else {
        console.log('App came to foreground');
        // Resume operations
    }
});

// Keep service worker alive for GPS tracking
self.addEventListener('message', event => {
    if (event.data && event.data.type === 'KEEP_SW_ALIVE') {
        console.log('Keeping service worker alive for GPS tracking');
        event.ports[0].postMessage({type: 'SW_ALIVE'});
    }
});

// Periodic background sync for fitness data
self.addEventListener('periodicsync', event => {
    if (event.tag === 'fitness-data-sync') {
        console.log('Periodic sync for fitness data');
        event.waitUntil(syncFitnessData());
    }
});

async function syncFitnessData() {
    try {
        // Sync fitness data with external services
        console.log('Syncing fitness data...');
        // Implementation would depend on external fitness APIs
        return Promise.resolve();
    } catch (error) {
        console.error('Fitness data sync failed:', error);
        throw error;
    }
}