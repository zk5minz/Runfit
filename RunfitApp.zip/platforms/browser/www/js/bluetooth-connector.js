class BluetoothConnector {
    constructor() {
        this.device = null;
        this.server = null;
        this.service = null;
        this.characteristic = null;
        this.isConnected = false;
        this.heartRate = 0;
        this.callbacks = {
            onHeartRateUpdate: null,
            onConnectionUpdate: null,
            onError: null
        };

        // Heart Rate Service UUID
        this.HEART_RATE_SERVICE = '0000180d-0000-1000-8000-00805f9b34fb';
        this.HEART_RATE_CHARACTERISTIC = '00002a37-0000-1000-8000-00805f9b34fb';
    }

    // Check if Web Bluetooth is supported
    isBluetoothSupported() {
        return 'bluetooth' in navigator;
    }

    // Request Bluetooth device and connect
    async connectHeartRateMonitor() {
        try {
            if (!this.isBluetoothSupported()) {
                throw new Error('이 브라우저는 블루투스를 지원하지 않습니다');
            }

            // Request device
            console.log('Requesting Bluetooth device...');
            this.device = await navigator.bluetooth.requestDevice({
                filters: [
                    { services: [this.HEART_RATE_SERVICE] },
                    { name: 'Heart Rate' },
                    { namePrefix: 'HR' }
                ],
                optionalServices: [this.HEART_RATE_SERVICE]
            });

            console.log('Device selected:', this.device.name);

            // Listen for disconnection
            this.device.addEventListener('gattserverdisconnected', () => {
                console.log('Device disconnected');
                this.handleDisconnection();
            });

            // Connect to GATT server
            console.log('Connecting to GATT server...');
            this.server = await this.device.gatt.connect();

            // Get Heart Rate service
            console.log('Getting Heart Rate service...');
            this.service = await this.server.getPrimaryService(this.HEART_RATE_SERVICE);

            // Get Heart Rate characteristic
            console.log('Getting Heart Rate characteristic...');
            this.characteristic = await this.service.getCharacteristic(this.HEART_RATE_CHARACTERISTIC);

            // Start notifications
            console.log('Starting heart rate notifications...');
            await this.characteristic.startNotifications();

            // Listen for heart rate updates
            this.characteristic.addEventListener('characteristicvaluechanged', (event) => {
                this.handleHeartRateData(event.target.value);
            });

            this.isConnected = true;
            console.log('Heart rate monitor connected successfully');

            // Trigger connection callback
            if (this.callbacks.onConnectionUpdate) {
                this.callbacks.onConnectionUpdate(true, this.device.name);
            }

            return true;

        } catch (error) {
            console.error('Bluetooth connection failed:', error);
            
            let errorMessage = '심박수 모니터 연결에 실패했습니다';
            
            if (error.message.includes('User cancelled')) {
                errorMessage = '블루투스 연결이 취소되었습니다';
            } else if (error.message.includes('not supported')) {
                errorMessage = '이 브라우저는 블루투스를 지원하지 않습니다';
            } else if (error.message.includes('not found')) {
                errorMessage = '심박수 모니터를 찾을 수 없습니다';
            }

            if (this.callbacks.onError) {
                this.callbacks.onError(errorMessage);
            }

            return false;
        }
    }

    // Handle heart rate data
    handleHeartRateData(value) {
        try {
            // Heart Rate Measurement format
            const flags = value.getUint8(0);
            let heartRate;

            if (flags & 0x01) {
                // 16-bit heart rate value
                heartRate = value.getUint16(1, true);
            } else {
                // 8-bit heart rate value
                heartRate = value.getUint8(1);
            }

            this.heartRate = heartRate;
            console.log('Heart rate:', heartRate, 'BPM');

            // Trigger heart rate update callback
            if (this.callbacks.onHeartRateUpdate) {
                this.callbacks.onHeartRateUpdate(heartRate);
            }

        } catch (error) {
            console.error('Error parsing heart rate data:', error);
            if (this.callbacks.onError) {
                this.callbacks.onError('심박수 데이터 읽기 오류');
            }
        }
    }

    // Handle disconnection
    handleDisconnection() {
        this.isConnected = false;
        this.heartRate = 0;
        this.device = null;
        this.server = null;
        this.service = null;
        this.characteristic = null;

        console.log('Heart rate monitor disconnected');

        // Trigger connection callback
        if (this.callbacks.onConnectionUpdate) {
            this.callbacks.onConnectionUpdate(false, null);
        }
    }

    // Disconnect from device
    async disconnect() {
        try {
            if (this.device && this.device.gatt.connected) {
                await this.device.gatt.disconnect();
            }
            this.handleDisconnection();
        } catch (error) {
            console.error('Error disconnecting:', error);
        }
    }

    // Get current heart rate
    getHeartRate() {
        return this.heartRate;
    }

    // Check connection status
    isDeviceConnected() {
        return this.isConnected && this.device && this.device.gatt.connected;
    }

    // Get connected device name
    getDeviceName() {
        return this.device ? this.device.name : null;
    }

    // Set callbacks
    setCallbacks(callbacks) {
        this.callbacks = { ...this.callbacks, ...callbacks };
    }

    // Calculate heart rate zone
    getHeartRateZone(age = 30) {
        if (this.heartRate === 0) return null;

        const maxHeartRate = 220 - age;
        const percentage = (this.heartRate / maxHeartRate) * 100;

        if (percentage < 50) {
            return { zone: 1, name: '워밍업', color: '#94A3B8' };
        } else if (percentage < 60) {
            return { zone: 2, name: '지방 연소', color: '#06B6D4' };
        } else if (percentage < 70) {
            return { zone: 3, name: '유산소', color: '#10B981' };
        } else if (percentage < 80) {
            return { zone: 4, name: '무산소', color: '#F59E0B' };
        } else if (percentage < 90) {
            return { zone: 5, name: '최대 운동', color: '#EF4444' };
        } else {
            return { zone: 6, name: '위험', color: '#DC2626' };
        }
    }

    // Get average heart rate
    calculateAverageHeartRate(heartRateHistory) {
        if (!heartRateHistory || heartRateHistory.length === 0) return 0;
        
        const sum = heartRateHistory.reduce((acc, hr) => acc + hr, 0);
        return Math.round(sum / heartRateHistory.length);
    }

    // Simulate heart rate for testing (remove in production)
    startSimulation() {
        console.log('Starting heart rate simulation...');
        this.isConnected = true;
        
        if (this.callbacks.onConnectionUpdate) {
            this.callbacks.onConnectionUpdate(true, 'Simulated HR Monitor');
        }

        // Simulate heart rate between 60-180 BPM
        this.simulationInterval = setInterval(() => {
            const baseRate = 120;
            const variation = Math.random() * 40 - 20; // ±20 BPM variation
            this.heartRate = Math.max(60, Math.min(180, Math.round(baseRate + variation)));
            
            if (this.callbacks.onHeartRateUpdate) {
                this.callbacks.onHeartRateUpdate(this.heartRate);
            }
        }, 1000);
    }

    // Stop simulation
    stopSimulation() {
        if (this.simulationInterval) {
            clearInterval(this.simulationInterval);
            this.simulationInterval = null;
        }
        this.handleDisconnection();
    }
}

// Export for use in other modules
window.BluetoothConnector = BluetoothConnector;