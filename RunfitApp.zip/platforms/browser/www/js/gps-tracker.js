class GPSTracker {
    constructor() {
        this.watchId = null;
        this.isTracking = false;
        this.currentPosition = null;
        this.route = [];
        this.totalDistance = 0;
        this.callbacks = {
            onLocationUpdate: null,
            onDistanceUpdate: null,
            onError: null
        };
        
        this.options = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 1000
        };
    }

    // Request geolocation permission and get current position
    async requestPermission() {
        try {
            // Check for Cordova geolocation plugin first
            if (window.cordova && navigator.geolocation) {
                // Cordova geolocation is available
                console.log('Using Cordova geolocation');
            } else if (!navigator.geolocation) {
                throw new Error('GPS를 지원하지 않는 기기입니다');
            }

            return new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(
                    position => {
                        this.currentPosition = position;
                        resolve(position);
                    },
                    error => {
                        const errorMessages = {
                            1: 'GPS 권한이 거부되었습니다',
                            2: 'GPS를 사용할 수 없습니다',
                            3: 'GPS 위치 요청 시간이 초과되었습니다'
                        };
                        reject(new Error(errorMessages[error.code] || 'GPS 오류가 발생했습니다'));
                    },
                    this.options
                );
            });
        } catch (error) {
            throw error;
        }
    }

    // Start tracking GPS location
    startTracking() {
        if (!navigator.geolocation || this.isTracking) {
            return false;
        }

        this.isTracking = true;
        this.route = [];
        this.totalDistance = 0;

        // Add current position as starting point
        if (this.currentPosition) {
            this.route.push({
                latitude: this.currentPosition.coords.latitude,
                longitude: this.currentPosition.coords.longitude,
                timestamp: Date.now(),
                accuracy: this.currentPosition.coords.accuracy
            });
        }

        this.watchId = navigator.geolocation.watchPosition(
            position => this.handlePositionUpdate(position),
            error => this.handleError(error),
            this.options
        );

        return true;
    }

    // Stop tracking GPS location
    stopTracking() {
        if (!this.isTracking || !this.watchId) {
            return;
        }

        navigator.geolocation.clearWatch(this.watchId);
        this.watchId = null;
        this.isTracking = false;
    }

    // Handle position updates
    handlePositionUpdate(position) {
        if (!this.isTracking) return;

        const newPoint = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            timestamp: Date.now(),
            accuracy: position.coords.accuracy
        };

        // Only add point if accuracy is reasonable (less than 50 meters)
        if (position.coords.accuracy > 50) {
            console.warn('GPS accuracy too low:', position.coords.accuracy);
            return;
        }

        // Calculate distance from last point
        if (this.route.length > 0) {
            const lastPoint = this.route[this.route.length - 1];
            const distance = this.calculateDistance(
                lastPoint.latitude,
                lastPoint.longitude,
                newPoint.latitude,
                newPoint.longitude
            );

            // Only add point if moved more than 5 meters to avoid GPS noise
            if (distance >= 0.005) {
                this.route.push(newPoint);
                this.totalDistance += distance;

                // Trigger distance update callback
                if (this.callbacks.onDistanceUpdate) {
                    this.callbacks.onDistanceUpdate(this.totalDistance);
                }
            }
        } else {
            this.route.push(newPoint);
        }

        this.currentPosition = position;

        // Trigger location update callback
        if (this.callbacks.onLocationUpdate) {
            this.callbacks.onLocationUpdate(position);
        }
    }

    // Handle GPS errors
    handleError(error) {
        console.error('GPS Error:', error);
        
        const errorMessages = {
            1: 'GPS 권한이 거부되었습니다',
            2: 'GPS를 사용할 수 없습니다',
            3: 'GPS 위치 요청 시간이 초과되었습니다'
        };

        const errorMessage = errorMessages[error.code] || 'GPS 오류가 발생했습니다';
        
        if (this.callbacks.onError) {
            this.callbacks.onError(errorMessage);
        }
    }

    // Calculate distance between two points using Haversine formula
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = this.toRadians(lat2 - lat1);
        const dLon = this.toRadians(lon2 - lon1);
        
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
                  Math.sin(dLon / 2) * Math.sin(dLon / 2);
        
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c; // Distance in kilometers
    }

    // Convert degrees to radians
    toRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    // Get current location
    getCurrentLocation() {
        return this.currentPosition;
    }

    // Get total distance
    getTotalDistance() {
        return this.totalDistance;
    }

    // Get full route
    getRoute() {
        return this.route;
    }

    // Set callbacks
    setCallbacks(callbacks) {
        this.callbacks = { ...this.callbacks, ...callbacks };
    }

    // Calculate current pace (minutes per kilometer)
    calculateCurrentPace(timeElapsed) {
        if (this.totalDistance === 0) return 0;
        
        const timeInMinutes = timeElapsed / (1000 * 60);
        const paceMinutes = timeInMinutes / this.totalDistance;
        
        return paceMinutes;
    }

    // Get route bounds for map fitting
    getRouteBounds() {
        if (this.route.length === 0) return null;

        let minLat = this.route[0].latitude;
        let maxLat = this.route[0].latitude;
        let minLon = this.route[0].longitude;
        let maxLon = this.route[0].longitude;

        this.route.forEach(point => {
            minLat = Math.min(minLat, point.latitude);
            maxLat = Math.max(maxLat, point.latitude);
            minLon = Math.min(minLon, point.longitude);
            maxLon = Math.max(maxLon, point.longitude);
        });

        return [[minLat, minLon], [maxLat, maxLon]];
    }

    // Smooth route to remove GPS noise
    smoothRoute(route = this.route) {
        if (route.length < 3) return route;

        const smoothed = [route[0]]; // Keep first point
        
        for (let i = 1; i < route.length - 1; i++) {
            const prev = route[i - 1];
            const current = route[i];
            const next = route[i + 1];
            
            // Simple moving average for smoothing
            const smoothedPoint = {
                latitude: (prev.latitude + current.latitude + next.latitude) / 3,
                longitude: (prev.longitude + current.longitude + next.longitude) / 3,
                timestamp: current.timestamp,
                accuracy: current.accuracy
            };
            
            smoothed.push(smoothedPoint);
        }
        
        smoothed.push(route[route.length - 1]); // Keep last point
        return smoothed;
    }

    // Export route data
    exportRoute() {
        return {
            route: this.route,
            totalDistance: this.totalDistance,
            startTime: this.route.length > 0 ? this.route[0].timestamp : null,
            endTime: this.route.length > 0 ? this.route[this.route.length - 1].timestamp : null,
            smoothedRoute: this.smoothRoute()
        };
    }
}

// Export for use in other modules
window.GPSTracker = GPSTracker;