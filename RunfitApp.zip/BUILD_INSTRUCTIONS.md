# RunTracker Android 빌드 가이드

## 🔧 필수 개발 도구 설치

### 1. Java Development Kit (JDK) 설치
```bash
# Oracle JDK 8 다운로드 및 설치
# URL: https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html
# 또는 OpenJDK 사용:
winget install Microsoft.OpenJDK.8
```

### 2. Android SDK 설치
```bash
# Android Studio 설치 (권장)
winget install Google.AndroidStudio

# 또는 Command Line Tools만 설치
# URL: https://developer.android.com/studio#cmdline-tools
```

### 3. 환경 변수 설정
Windows 환경 변수에 다음을 추가:
```
ANDROID_HOME=C:\Users\[사용자명]\AppData\Local\Android\Sdk
JAVA_HOME=C:\Program Files\Java\jdk1.8.0_XXX

PATH에 추가:
%ANDROID_HOME%\tools
%ANDROID_HOME%\tools\bin
%ANDROID_HOME%\platform-tools
%JAVA_HOME%\bin
```

### 4. Android SDK 구성 요소 설치
```bash
# Android Studio SDK Manager에서 설치하거나:
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

## 🚀 빌드 명령어

### 디버그 APK 빌드
```bash
cd RunfitApp
cordova build android
```

### 릴리즈 APK 빌드
```bash
# 키스토어 생성 (최초 1회)
keytool -genkey -v -keystore runtracker-release.keystore -alias runtracker -keyalg RSA -keysize 2048 -validity 10000

# build.json 파일 생성
cat > build.json << EOF
{
    "android": {
        "release": {
            "keystore": "runtracker-release.keystore",
            "storePassword": "YOUR_PASSWORD",
            "alias": "runtracker",
            "password": "YOUR_PASSWORD"
        }
    }
}
EOF

# 릴리즈 빌드
cordova build android --release
```

### AAB (Android App Bundle) 빌드
```bash
# Gradle 설정 수정 후
cordova build android --release -- --packageType=bundle
```

## 📱 APK 위치

빌드가 완료되면 다음 위치에서 APK 파일을 찾을 수 있습니다:

- **디버그 APK**: `platforms/android/app/build/outputs/apk/debug/app-debug.apk`
- **릴리즈 APK**: `platforms/android/app/build/outputs/apk/release/app-release.apk`
- **AAB 파일**: `platforms/android/app/build/outputs/bundle/release/app-release.aab`

## 🔐 키스토어 관리

릴리즈 빌드를 위해서는 키스토어가 필요합니다:

```bash
# 키스토어 생성
keytool -genkey -v -keystore runtracker-release.keystore -alias runtracker -keyalg RSA -keysize 2048 -validity 10000

# 키스토어 정보 확인
keytool -list -v -keystore runtracker-release.keystore
```

## 🧪 테스트 및 설치

### ADB를 통한 설치
```bash
# 디버그 APK 설치
adb install platforms/android/app/build/outputs/apk/debug/app-debug.apk

# 기존 앱 제거 후 설치
adb uninstall com.runfit.tracker
adb install platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

### 기기에서 직접 설치
1. APK 파일을 Android 기기로 복사
2. 기기 설정에서 "알 수 없는 출처" 허용
3. 파일 관리자에서 APK 파일 실행하여 설치

## 🐛 문제 해결

### 일반적인 오류들

1. **Java 버전 오류**
   ```bash
   # Java 8 사용 확인
   java -version
   javac -version
   ```

2. **Android SDK 경로 오류**
   ```bash
   # ANDROID_HOME 확인
   echo $ANDROID_HOME
   ```

3. **Gradle 빌드 오류**
   ```bash
   # Gradle 캐시 정리
   cd platforms/android
   ./gradlew clean
   ```

4. **권한 오류**
   - 모든 필요한 권한이 config.xml에 정의되어 있는지 확인
   - Android 6.0+ 기기에서는 런타임 권한 요청 필요

## 📋 체크리스트

빌드 전 확인사항:
- [ ] JDK 8 설치됨
- [ ] Android SDK 설치됨
- [ ] ANDROID_HOME 환경변수 설정됨
- [ ] PATH에 필요한 경로 추가됨
- [ ] 필요한 Android SDK 구성요소 설치됨
- [ ] config.xml 설정 완료
- [ ] 앱 아이콘 및 스플래시 이미지 준비됨

## 🚀 배포 준비

Google Play Store 배포를 위한 추가 단계:
1. 키스토어 안전하게 보관
2. 앱 서명 키 Google Play Console에 업로드
3. AAB 파일 빌드 및 업로드
4. 개인정보처리방침 및 앱 설명 작성
5. 스크린샷 및 앱 소개 이미지 준비

## 📞 지원

문제가 발생하면 다음을 참조하세요:
- Apache Cordova 공식 문서: https://cordova.apache.org/docs/
- Android 개발자 가이드: https://developer.android.com/guide