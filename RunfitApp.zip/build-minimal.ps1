# RunTracker Minimal Build Script
# Builds APK/AAB with minimal Android SDK setup

param(
    [string]$BuildType = "debug",
    [switch]$SetupEnv,
    [switch]$InstallTools
)

$ErrorActionPreference = "Continue"

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "RunTracker Minimal 빌드 스크립트" -ForegroundColor Cyan  
Write-Host "=====================================" -ForegroundColor Cyan

function Write-Success { param($Message); Write-Host "✅ $Message" -ForegroundColor Green }
function Write-Error { param($Message); Write-Host "❌ $Message" -ForegroundColor Red }
function Write-Info { param($Message); Write-Host "ℹ️ $Message" -ForegroundColor Blue }

# Check for required tools
Write-Info "환경 확인 중..."

$nodeVersion = try { & node --version 2>$null } catch { $null }
if ($nodeVersion) {
    Write-Success "Node.js: $nodeVersion"
} else {
    Write-Error "Node.js가 설치되지 않았습니다."
    Write-Host "https://nodejs.org/ 에서 다운로드하세요." -ForegroundColor Yellow
    exit 1
}

$cordovaVersion = try { & cordova --version 2>$null } catch { $null }
if ($cordovaVersion) {
    Write-Success "Cordova: $cordovaVersion"
} else {
    Write-Error "Cordova가 설치되지 않았습니다."
    if ($InstallTools) {
        Write-Info "Cordova 설치 중..."
        npm install -g cordova
    } else {
        Write-Host "npm install -g cordova 명령을 실행하세요." -ForegroundColor Yellow
        exit 1
    }
}

# Setup minimal environment if requested
if ($SetupEnv) {
    Write-Info "최소 Android 환경 설정 중..."
    
    $tempDir = "C:\temp\android-minimal"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    
    # Download minimal Android tools
    $platformToolsUrl = "https://dl.google.com/android/repository/platform-tools_r34.0.4-windows.zip"
    $platformToolsZip = "$tempDir\platform-tools.zip"
    
    if (!(Test-Path "$tempDir\platform-tools\adb.exe")) {
        Write-Info "Android Platform Tools 다운로드 중..."
        try {
            Invoke-WebRequest -Uri $platformToolsUrl -OutFile $platformToolsZip
            Expand-Archive -Path $platformToolsZip -DestinationPath $tempDir -Force
            Remove-Item $platformToolsZip
            Write-Success "Android Platform Tools 설치 완료"
        } catch {
            Write-Error "Platform Tools 다운로드 실패: $($_.Exception.Message)"
        }
    }
    
    # Set environment variables for this session
    $env:ANDROID_HOME = $tempDir
    $env:PATH = "$tempDir\platform-tools;$env:PATH"
}

# Build project
Write-Info "프로젝트 빌드 시작..."

if (!(Test-Path "config.xml")) {
    Write-Error "Cordova 프로젝트 루트 디렉터리에서 실행하세요."
    exit 1
}

# Check if Android platform is added
$platforms = cordova platform list 2>$null
if ($platforms -notlike "*android*") {
    Write-Info "Android 플랫폼 추가 중..."
    try {
        cordova platform add android
        Write-Success "Android 플랫폼 추가됨"
    } catch {
        Write-Error "Android 플랫폼 추가 실패. Android SDK가 필요합니다."
        Write-Host "대안 빌드 방법을 사용하세요: ALTERNATIVE_BUILD_GUIDE.md 참조" -ForegroundColor Yellow
        exit 1
    }
}

# Prepare project
Write-Info "프로젝트 준비 중..."
cordova prepare android

# Build based on type
switch ($BuildType.ToLower()) {
    "debug" {
        Write-Info "디버그 APK 빌드 중..."
        cordova build android --debug
        
        $debugApk = "platforms\android\app\build\outputs\apk\debug\app-debug.apk"
        if (Test-Path $debugApk) {
            $fileSize = [math]::Round((Get-Item $debugApk).Length / 1MB, 2)
            Write-Success "디버그 APK 빌드 완료! (크기: $fileSize MB)"
            Write-Host "파일 위치: $debugApk" -ForegroundColor Yellow
            
            # Show installation instructions
            Write-Host ""
            Write-Info "설치 방법:"
            Write-Host "  1. Android 기기에서 '개발자 옵션' 활성화" -ForegroundColor Gray
            Write-Host "  2. 'USB 디버깅' 허용" -ForegroundColor Gray
            Write-Host "  3. 다음 명령 실행: adb install -r `"$debugApk`"" -ForegroundColor Gray
        } else {
            Write-Error "디버그 APK 빌드 실패"
        }
    }
    
    "release" {
        Write-Info "릴리즈 빌드를 위한 키스토어 확인 중..."
        
        if (!(Test-Path "runtracker-release.keystore")) {
            Write-Info "키스토어 생성 중..."
            $keystorePassword = Read-Host "키스토어 비밀번호를 입력하세요" -AsSecureString
            $keystorePasswordText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($keystorePassword))
            
            keytool -genkey -v -keystore runtracker-release.keystore -alias runtracker -keyalg RSA -keysize 2048 -validity 10000 -storepass $keystorePasswordText -keypass $keystorePasswordText -dname "CN=RunTracker, OU=Dev, O=RunFit, L=Seoul, C=KR"
            
            # Create build.json
            $buildJson = @{
                android = @{
                    release = @{
                        keystore = "runtracker-release.keystore"
                        storePassword = $keystorePasswordText
                        alias = "runtracker"
                        password = $keystorePasswordText
                    }
                }
            }
            $buildJson | ConvertTo-Json -Depth 3 | Out-File "build.json" -Encoding UTF8
        }
        
        Write-Info "릴리즈 APK 빌드 중..."
        cordova build android --release
        
        $releaseApk = "platforms\android\app\build\outputs\apk\release\app-release.apk"
        if (Test-Path $releaseApk) {
            $fileSize = [math]::Round((Get-Item $releaseApk).Length / 1MB, 2)
            Write-Success "릴리즈 APK 빌드 완료! (크기: $fileSize MB)"
            Write-Host "파일 위치: $releaseApk" -ForegroundColor Yellow
        } else {
            Write-Error "릴리즈 APK 빌드 실패"
        }
    }
    
    "aab" {
        Write-Info "AAB (Android App Bundle) 빌드 중..."
        cordova build android --release -- --packageType=bundle
        
        $aabFile = "platforms\android\app\build\outputs\bundle\release\app-release.aab"
        if (Test-Path $aabFile) {
            $fileSize = [math]::Round((Get-Item $aabFile).Length / 1MB, 2)
            Write-Success "AAB 빌드 완료! (크기: $fileSize MB)"
            Write-Host "파일 위치: $aabFile" -ForegroundColor Yellow
            Write-Host "Google Play Console에 업로드하세요." -ForegroundColor Cyan
        } else {
            Write-Error "AAB 빌드 실패"
        }
    }
    
    "all" {
        Write-Info "모든 형식 빌드 중..."
        
        # Debug
        cordova build android --debug
        $debugApk = "platforms\android\app\build\outputs\apk\debug\app-debug.apk"
        if (Test-Path $debugApk) {
            Write-Success "디버그 APK 완료"
        }
        
        # Release APK
        cordova build android --release  
        $releaseApk = "platforms\android\app\build\outputs\apk\release\app-release.apk"
        if (Test-Path $releaseApk) {
            Write-Success "릴리즈 APK 완료"
        }
        
        # AAB
        cordova build android --release -- --packageType=bundle
        $aabFile = "platforms\android\app\build\outputs\bundle\release\app-release.aab"
        if (Test-Path $aabFile) {
            Write-Success "AAB 완료"
        }
    }
    
    default {
        Write-Error "알 수 없는 빌드 타입: $BuildType"
        Write-Host "사용법: .\build-minimal.ps1 [debug|release|aab|all]" -ForegroundColor Yellow
        exit 1
    }
}

# Show build summary
Write-Host ""
Write-Info "빌드 결과:"
$outputs = @(
    "platforms\android\app\build\outputs\apk\debug\app-debug.apk",
    "platforms\android\app\build\outputs\apk\release\app-release.apk", 
    "platforms\android\app\build\outputs\bundle\release\app-release.aab"
)

foreach ($output in $outputs) {
    if (Test-Path $output) {
        $fileSize = [math]::Round((Get-Item $output).Length / 1MB, 2)
        $fileName = Split-Path $output -Leaf
        Write-Host "  ✅ $fileName ($fileSize MB)" -ForegroundColor Green
    }
}

Write-Host ""
Write-Success "빌드 스크립트 완료!"

# Usage examples
Write-Host ""
Write-Host "사용법 예시:" -ForegroundColor Cyan
Write-Host "  .\build-minimal.ps1 debug          # 디버그 APK만" -ForegroundColor Gray
Write-Host "  .\build-minimal.ps1 release        # 릴리즈 APK만" -ForegroundColor Gray
Write-Host "  .\build-minimal.ps1 aab            # AAB만" -ForegroundColor Gray
Write-Host "  .\build-minimal.ps1 all            # 모든 형식" -ForegroundColor Gray
Write-Host "  .\build-minimal.ps1 debug -SetupEnv # 환경 설정 포함" -ForegroundColor Gray