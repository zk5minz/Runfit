# RunTracker Android Build Script (PowerShell)
param(
    [string]$BuildType = "debug"
)

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "RunTracker Android 빌드 스크립트" -ForegroundColor Cyan  
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# Functions
function Test-Command {
    param($Command)
    try {
        Get-Command $Command -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

function Write-Success {
    param($Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Error {
    param($Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Info {
    param($Message)
    Write-Host "ℹ️ $Message" -ForegroundColor Blue
}

# Environment Check
Write-Info "1. 개발 환경 확인 중..."

# Check Java
if (Test-Command "java") {
    $javaVersion = & java -version 2>&1 | Select-String "version"
    Write-Success "Java 설치됨: $javaVersion"
} else {
    Write-Error "Java가 설치되지 않았습니다."
    Write-Host "Oracle JDK 8 또는 OpenJDK 8을 설치하세요."
    exit 1
}

# Check ANDROID_HOME
if ($env:ANDROID_HOME) {
    Write-Success "ANDROID_HOME 설정됨: $env:ANDROID_HOME"
} else {
    Write-Error "ANDROID_HOME 환경변수가 설정되지 않았습니다."
    Write-Host "Android SDK를 설치하고 ANDROID_HOME을 설정하세요."
    exit 1
}

# Check Cordova
if (Test-Command "cordova") {
    $cordovaVersion = & cordova --version
    Write-Success "Cordova 설치됨: $cordovaVersion"
} else {
    Write-Error "Cordova가 설치되지 않았습니다."
    Write-Host "npm install -g cordova 명령을 실행하세요."
    exit 1
}

Write-Host ""

# Build Selection
if ($BuildType -eq "interactive") {
    Write-Host "2. 빌드 옵션을 선택하세요:"
    Write-Host "   [1] 디버그 APK 빌드"
    Write-Host "   [2] 릴리즈 APK 빌드" 
    Write-Host "   [3] AAB (App Bundle) 빌드"
    Write-Host "   [4] 모든 형식 빌드"
    $choice = Read-Host "선택 (1-4)"
    
    switch ($choice) {
        "1" { $BuildType = "debug" }
        "2" { $BuildType = "release" }
        "3" { $BuildType = "aab" }
        "4" { $BuildType = "all" }
        default { 
            Write-Error "잘못된 선택입니다."
            exit 1
        }
    }
}

# Create build.json if it doesn't exist for release builds
if (($BuildType -eq "release" -or $BuildType -eq "aab" -or $BuildType -eq "all") -and !(Test-Path "build.json")) {
    Write-Info "build.json 파일이 없습니다. 생성하시겠습니까? (Y/N)"
    $createBuildJson = Read-Host
    
    if ($createBuildJson -eq "Y" -or $createBuildJson -eq "y") {
        $keystorePassword = Read-Host "키스토어 비밀번호를 입력하세요" -AsSecureString
        $keystorePasswordText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($keystorePassword))
        
        $buildJsonContent = @{
            android = @{
                release = @{
                    keystore = "runtracker-release.keystore"
                    storePassword = $keystorePasswordText
                    alias = "runtracker"
                    password = $keystorePasswordText
                }
            }
        }
        
        $buildJsonContent | ConvertTo-Json -Depth 3 | Out-File -FilePath "build.json" -Encoding UTF8
        Write-Success "build.json 파일이 생성되었습니다."
    }
}

# Build Functions
function Build-Debug {
    Write-Info "디버그 APK 빌드 중..."
    & cordova build android --debug
    
    if ($LASTEXITCODE -eq 0) {
        Write-Success "디버그 APK 빌드 완료!"
        $debugApkPath = "platforms\android\app\build\outputs\apk\debug\app-debug.apk"
        if (Test-Path $debugApkPath) {
            Write-Host "파일 위치: $debugApkPath" -ForegroundColor Yellow
            return $debugApkPath
        }
    } else {
        Write-Error "디버그 빌드 실패"
    }
    return $null
}

function Build-Release {
    Write-Info "릴리즈 APK 빌드 중..."
    
    # Check keystore
    if (!(Test-Path "runtracker-release.keystore")) {
        Write-Info "키스토어가 없습니다. 새로 생성하시겠습니까? (Y/N)"
        $createKeystore = Read-Host
        
        if ($createKeystore -eq "Y" -or $createKeystore -eq "y") {
            Write-Info "키스토어 생성 중..."
            & keytool -genkey -v -keystore runtracker-release.keystore -alias runtracker -keyalg RSA -keysize 2048 -validity 10000
            
            if ($LASTEXITCODE -ne 0) {
                Write-Error "키스토어 생성 실패"
                return $null
            }
        } else {
            Write-Error "키스토어 없이는 릴리즈 빌드를 할 수 없습니다."
            return $null
        }
    }
    
    & cordova build android --release
    
    if ($LASTEXITCODE -eq 0) {
        Write-Success "릴리즈 APK 빌드 완료!"
        $releaseApkPath = "platforms\android\app\build\outputs\apk\release\app-release.apk"
        if (Test-Path $releaseApkPath) {
            Write-Host "파일 위치: $releaseApkPath" -ForegroundColor Yellow
            return $releaseApkPath
        }
    } else {
        Write-Error "릴리즈 빌드 실패"
    }
    return $null
}

function Build-AAB {
    Write-Info "AAB 빌드 중..."
    & cordova build android --release -- --packageType=bundle
    
    if ($LASTEXITCODE -eq 0) {
        Write-Success "AAB 빌드 완료!"
        $aabPath = "platforms\android\app\build\outputs\bundle\release\app-release.aab"
        if (Test-Path $aabPath) {
            Write-Host "파일 위치: $aabPath" -ForegroundColor Yellow
            return $aabPath
        }
    } else {
        Write-Error "AAB 빌드 실패"
    }
    return $null
}

# Execute builds based on selection
$builtFiles = @()

switch ($BuildType) {
    "debug" {
        $file = Build-Debug
        if ($file) { $builtFiles += $file }
    }
    "release" {
        $file = Build-Release
        if ($file) { $builtFiles += $file }
    }
    "aab" {
        $file = Build-AAB
        if ($file) { $builtFiles += $file }
    }
    "all" {
        Write-Info "모든 형식 빌드 중..."
        
        $debugFile = Build-Debug
        if ($debugFile) { $builtFiles += $debugFile }
        
        $releaseFile = Build-Release
        if ($releaseFile) { $builtFiles += $releaseFile }
        
        $aabFile = Build-AAB
        if ($aabFile) { $builtFiles += $aabFile }
        
        Write-Success "모든 빌드 완료!"
    }
}

# Display results
Write-Host ""
Write-Info "빌드 결과:"
if ($builtFiles.Count -gt 0) {
    foreach ($file in $builtFiles) {
        Write-Host "   - $file" -ForegroundColor Yellow
        $fileInfo = Get-Item $file
        Write-Host "     크기: $([math]::Round($fileInfo.Length / 1MB, 2)) MB" -ForegroundColor Gray
    }
    
    # Offer to install
    Write-Host ""
    Write-Info "Android 기기에 설치하시겠습니까? (기기가 연결되어 있어야 합니다) (Y/N)"
    $installApp = Read-Host
    
    if ($installApp -eq "Y" -or $installApp -eq "y") {
        # Try to find debug APK first, then release APK
        $apkToInstall = $builtFiles | Where-Object { $_ -like "*debug*" } | Select-Object -First 1
        if (-not $apkToInstall) {
            $apkToInstall = $builtFiles | Where-Object { $_ -like "*.apk" } | Select-Object -First 1
        }
        
        if ($apkToInstall) {
            Write-Info "설치 중: $apkToInstall"
            & adb install -r $apkToInstall
            
            if ($LASTEXITCODE -eq 0) {
                Write-Success "앱이 성공적으로 설치되었습니다!"
            } else {
                Write-Error "앱 설치 실패. ADB가 설치되어 있고 기기가 연결되어 있는지 확인하세요."
            }
        }
    }
} else {
    Write-Error "빌드된 파일이 없습니다."
}

Write-Host ""
Write-Success "빌드 스크립트 완료!"

# Usage examples
Write-Host ""
Write-Host "사용법 예시:" -ForegroundColor Cyan
Write-Host "  .\build.ps1 debug          # 디버그 빌드만" -ForegroundColor Gray
Write-Host "  .\build.ps1 release        # 릴리즈 빌드만" -ForegroundColor Gray
Write-Host "  .\build.ps1 aab            # AAB 빌드만" -ForegroundColor Gray  
Write-Host "  .\build.ps1 all            # 모든 형식 빌드" -ForegroundColor Gray
Write-Host "  .\build.ps1 interactive    # 대화형 모드" -ForegroundColor Gray